 //start loading screen
$(window).load(function()
{
	$("body").css("overflow","auto");
	$(".loading-overlay .spinner").fadeOut(2000,
	function()
	{
		$(this).parent().fadeOut(2000,
		function(){
			$(this).remove();
		});
		
	});
});
//end loading screen
//==========================================
//start loading screen
$(window).load(function()
{	
	$(".loading-overlay .spinner").fadeOut(1000,
	function()
	{
		$(this).parent().fadeOut(2000,
		function()
		{
			$(this).remove();
		});
		
	});
});
//caching the scroll top element
	var scrollButton = $("#scroll-top");
	$(window).scroll(function()
	{
		$(this).scrollTop()>= 400?scrollButton.show():scrollButton.hide();
	});
	//click on button to scroll top
	scrollButton.click(function()
	{
	$("html,body").animate({scrollTop:0},600);	
	});

//==========================================
$(function(){
	'use strict';
	//hide place holder on form focus
	$('[placeholder]').focus(function(){
		$(this).attr('data-text',$(this).attr('placeholder'));
		$(this).attr('placeholder','');
	}).blur(function(){
		$(this).attr('placeholder',$(this).attr('data-text'));
	});	
});
//******************************* 
 function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#imagePreview').css('background-image', 'url('+e.target.result +')');
                $('#imagePreview').hide();
                $('#imagePreview').fadeIn(650);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#imageUpload").change(function() {
        readURL(this);
    });
/************************************************* */
// $("input").click(function(){
// 	$("img").show();
//   });